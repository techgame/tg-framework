import pprint
print "You imported me!", __name__
print "   ", __file__
print
v = vars().copy()
del v['__builtins__']
del v['pprint']
pprint.pprint(v)
print
